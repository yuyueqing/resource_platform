<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>grid</title>
    <script type="text/javascript" src="../js/jquery-1.10.2.min.js"></script>
    <script src="../js/radialindicator.js"></script>
    <script src="../js/circle.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    
  
    <link rel="stylesheet" href="../css/add_succeed.css">
     <link rel="stylesheet" href="../css/public.css">
<!--      <span style="font-size:18px;"> </span><span style="font-size:24px;"><meta http-equiv="refresh" content="3;URL=index.php"> </span>  -->
<span style="font-size:24px;">
  </head>

  <body> <!-- head -->
    <nav class="navbar navbar-default  navbar-fixed-top head">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xs-12">
              <span>添加格子</span>
            </div>
          </div>
        </div>
      </nav>


    <div class="container-fluid">
     
      
      <!-- middle -->
      <div class="row middle">
       <div class='col-xs-1'></div>
        <div class="col-xs-10">
        <img src="../picture/succeed.png" alt="">
          </br> 
          <span>添加格子成功!</span>
          </br>
          <hr width="80%" SIZE=10 /> 
          </br>
       
            <a href="index.php"><button type="button" class="btn btn-group-lg btn-default">确定</button></a>
            <br>
            <br>

            <span>3秒钟后自动返回</span>
          </div>
          <div class='col-xs-1'></div>
        </div>
        </body>
      </html>