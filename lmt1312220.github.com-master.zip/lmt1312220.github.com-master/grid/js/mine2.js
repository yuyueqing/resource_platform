$(document).ready(function(){
	$(".cha").click(function(){
		 $('.text').val("");
	});
	
	
})


    
       
 
