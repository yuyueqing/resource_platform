$(document).ready(function(){
	$("#left").click(function(){
		  $(".a").show();
		  $(".yingzi").show();
	});
	$(".img3").click(function(){
		 $(".a").hide();
		 $(".yingzi").hide();
	});
	$(".img33").click(function(){
		 $(".b").hide();
		 $(".yingzi").hide();
	});
	$("#button").click(function(){
	     $(".b").show();
	     $(".yingzi").show();
	});
	
})


    
       
 
