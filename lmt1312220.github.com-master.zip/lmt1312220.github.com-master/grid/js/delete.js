$(document).ready(function(){
    $("#delbutton").click(function(){  
        $("div.modal-body ").html("删除该专项块后本金和利息将会划入钱包，确定删除该专项块？");
  });  
})