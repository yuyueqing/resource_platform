$(document).ready(function(){
$(".purse").click(function(){
    $(".purse>img").toggle();
});
});
